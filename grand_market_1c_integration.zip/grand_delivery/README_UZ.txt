GRAND MARKET DELIVERY — 1C CommerceML 2 интеграцияси (синов версияси)

1. GitHub репозиторийсидаги app.py ни шу файл билан алмаштиринг.
2. requirements.txt ни қўшинг. Мавжуд index.html ни ўзгартирманг.
3. Render Environment га EXCHANGE_USER ва EXCHANGE_PASSWORD ни кучли махфий қийматлар билан қўшинг.
4. ADMIN_KEY, BOT_TOKEN, OWNER_CHAT_ID каби аввалги ўзгарувчиларни сақланг.
5. Render Start Command: gunicorn --workers 1 --bind 0.0.0.0:$PORT app:app
6. Render қайта ишга тушгач, 1C манзили:
   https://grand-market-delivery-1.onrender.com/1c/exchange
   Логин EXCHANGE_USER, пароль EXCHANGE_PASSWORD қийматлари.
7. Аввал 1С да 1 та тест товар билан синаб кўринг. Кейин тўлиқ импорт қилинг.

МУҲИМ:
- Бу минимал интеграция: 1С конфигурацияси ва CommerceML XML тузилишига қараб ўзгартириш талаб қилиши мумкин.
- ZIP архив импорти қўлланмайди (zip=no).
- 1C сессиялари RAM да сақланади; 1 worker ишлатинг.
- Render бепул ephemeral disk да SQLite файллари қайта деплойда йўқолиши мумкин.
  Persistent disk ёки PostgreSQL миграцияси керак. SQLite учун DB_PATH ни persistent disk га ўрнатинг.
- Буюртмалар query орқали барчаси узатилади; 1С да такрорларни Ид бўйича текширинг.
- Реал ишлаб чиқаришга чиқаришдан олдин аниқ 1С XML билан тест ва хавфсизлик текшируви шарт.
- Сайтнинг олдинги JavaScript коди рақамли demo id ларга боғлиқ бўлса, товар id ларини string сифатида ишлатишга мослаштириш керак.
